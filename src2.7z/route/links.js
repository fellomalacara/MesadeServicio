const express = require('express');
const router = express.Router();

const pool = require('../database');
const { isLoggedIn } = require('../lib/auth');

router.get('/add', isLoggedIn, (req, res) => {
    res.render('links/add');
});

router.post('/add', isLoggedIn, async(req, res) => {
    const { Nombre, No_Colaborador, created_at, rol, correo, Estado, Supervisor, puesto, Mes, Calificacion, Documentacion, Puntos_Documentacion, Asignacion, Puntos_Asignacion, Logueo, Puntos_Logueo, Calidad, Puntos_Calidad, Puntos_FCR, Faltas_Injustificadas, Retardos, Asistencia, Puntos_Asistencia, Dinero, Amonestaciones, Retro01, Retro02, Retro03, Retro04, imagen, observaciones,FCR, } = req.body;
    const newLink = {
        Nombre,
        No_Colaborador,
        created_at,
        rol,
        correo,
        Estado,
        Supervisor,
        puesto,
        Mes,
        Calificacion,
        Documentacion,
        Puntos_Documentacion,
        Asignacion,
        Puntos_Asignacion,
        Logueo,
        Puntos_Logueo,
        Calidad,
        Puntos_Calidad,
        Puntos_FCR,
        Faltas_Injustificadas,
        Retardos,
        Asistencia,
        Puntos_Asistencia,
        Dinero,
        Amonestaciones,
        Retro01,
        Retro02,
        Retro03,
        Retro04,
        imagen,
        observaciones,
        FCR,

        user_id: req.user.id
    };
    await pool.query('INSERT INTO links set ?', [newLink]);
    req.flash('success', 'Perfil Agregado Satisfactoriamente');
    res.redirect('/links');
});

router.get('/', isLoggedIn, async(req, res) => {
    const links = await pool.query('SELECT * FROM links WHERE user_id = ?', [req.user.id]);
    res.render('links/list', { links });
});
router.get('/print', isLoggedIn, async(req, res) => {
    const links = await pool.query('SELECT * FROM links WHERE user_id = ?', [req.user.id]);
    res.render('links/print', { links });
});

router.get('/delete/:id', isLoggedIn, async(req, res) => {
    const { id } = req.params;
    await pool.query('DELETE FROM links WHERE id =?', [id]);
    req.flash('success', 'registro eliminado correctamente!');
    res.redirect('/links');
});

router.get('/edit/:id', isLoggedIn, async(req, res) => {
    const { id } = req.params;
    const links = await pool.query('SELECT * FROM links WHERE id = ?', [id]);
    res.render('links/edit', { links: links[0] });
});
router.post('/edit/:id', isLoggedIn, async(req, res) => {
    const { id } = req.params;
    const { Retro01, Retro02, Retro03, Retro04 } = req.body;
    const newLink = {
        Retro01,
        Retro02,
        Retro03,
        Retro04,
    };
    await pool.query('UPDATE links set ? WHERE id = ?', [newLink, id]);
    req.flash('success', 'Datos Actualizados correctamente!');
    res.redirect('/links');
});

router.get('/score', isLoggedIn, (req, res) => {
    res.render('links/score');
});

router.post('/score', isLoggedIn, async(req, res) => {
    const { id, Mes, Documentacion,p_Documentacion,P_Asignacion } = req.body;
    const newLink = {
        Nombre,
        No_Colaborador,
        created_at,
        rol,
        correo,
        Estado,
        Supervisor,
        puesto,
        Mes,
        Calificacion,
        Documentacion,
        Puntos_Documentacion,
        Asignacion,
        Puntos_Asignacion,
        Logueo,
        Puntos_Logueo,
        Calidad,
        Puntos_Calidad,
        Puntos_FCR,
        Faltas_Injustificadas,
        Retardos,
        Asistencia,
        Puntos_Asistencia,
        Dinero,
        Amonestaciones,
        Retro01,
        Retro02,
        Retro03,
        Retro04,
        imagen,
        observaciones,
        FCR,

        user_id: req.user.id
    };
    await pool.query('INSERT INTO score set ?', [newLink]);
    req.flash('success', 'Perfil Agregado Satisfactoriamente');
    res.redirect('/links');
});

module.exports = router;